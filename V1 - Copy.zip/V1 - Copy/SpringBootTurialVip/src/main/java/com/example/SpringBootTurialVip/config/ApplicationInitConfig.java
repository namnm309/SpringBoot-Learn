package com.example.SpringBootTurialVip.config;

import com.example.SpringBootTurialVip.entity.User;
import com.example.SpringBootTurialVip.enums.Role;
import com.example.SpringBootTurialVip.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
import java.util.HashSet;

//Tạo 1 admin khi install application
@Configuration
@RequiredArgsConstructor
@Slf4j//logger
public class ApplicationInitConfig {

    //@Autowired dùng @RequiredArgsConstructor thay thế
    private final PasswordEncoder passwordEncoder;

    //Sẽ đc khởi chạy khi application chạy
    //Khi run project s4 tạo 1 admin để quản trị hệ thống , chỉ tạo đc 1 lần duy nhất
    //Nếu trong db đã có adminb này thì sẽ ko tạo nữa
    @Bean
    ApplicationRunner applicationRunner(UserRepository userRepository){
        return args -> {
          //Check admin đã tồn tại
          if (userRepository.findByUsername("admin").isEmpty()) {
              var roles=new HashSet<String>();
              roles.add(Role.ADMIN.name());

              User user=User.builder()
                      .username("admin")
                      .password(passwordEncoder.encode("admin"))
                      .email("<EMAIL>")
                      .phone("0123456789")
                      .bod(new Date())
                      .gender("Unknown")
                      .roles(roles) //comment lỗi @Manytomany trong entity user
                      .build();

              userRepository.save(user);
              log.warn("Tài khoản admin đã đc khởi tạo với mật khẩu : admin ");
          }
        };
    }
}
