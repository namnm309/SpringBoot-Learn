package com.nofear.nac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NacApplicationTests {

	@Test
	void contextLoads() {
	}

}
