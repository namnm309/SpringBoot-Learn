package com.nofear.nac.password;


import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class BCryptPassword extends BCryptPasswordEncoder {
}
