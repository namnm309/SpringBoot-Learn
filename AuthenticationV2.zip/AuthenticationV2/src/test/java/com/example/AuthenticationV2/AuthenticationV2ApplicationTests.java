package com.example.AuthenticationV2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticationV2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
