package com.example.SpringBootTurialVip.enums;

public enum Role {
    ADMIN,
    STAFF,
    CUSTOMER
}
