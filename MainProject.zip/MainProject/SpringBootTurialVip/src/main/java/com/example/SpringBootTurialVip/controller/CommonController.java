package com.example.SpringBootTurialVip.controller;

public class CommonController {
}
