package com.example.DemoSelftest2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSelftest2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
