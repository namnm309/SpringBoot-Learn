package com.example.DemoSelfTest1.model;

// Enum for Service Type
public enum ServicesType {
    SINGLE, COMBO, MODIFY
}