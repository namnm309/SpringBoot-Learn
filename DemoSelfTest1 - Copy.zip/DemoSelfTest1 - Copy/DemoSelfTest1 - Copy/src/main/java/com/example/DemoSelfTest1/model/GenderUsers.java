package com.example.DemoSelfTest1.model;

// Enum for Gender
public enum GenderUsers {
    MALE, FEMALE
}