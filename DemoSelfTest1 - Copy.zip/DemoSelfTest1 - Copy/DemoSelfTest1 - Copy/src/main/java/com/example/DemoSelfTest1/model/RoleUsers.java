package com.example.DemoSelfTest1.model;


public enum RoleUsers {
        ADMIN, STAFF, CUSTOMER, CHILD
    }


